
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, BookOpen, Flame, MessageCircle, Star, Sparkles, ArrowRight, Users, Shield, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import HealingHub from '@/components/HealingHub';
import Journal from '@/components/Journal';
import HealingStreaks from '@/components/HealingStreaks';
import ConfessionRooms from '@/components/ConfessionRooms';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const sections = [
    {
      id: 'healing-hub',
      title: 'Healing Hub',
      icon: Heart,
      description: 'Connect with others on similar journeys',
      gradient: 'healing-gradient',
      component: HealingHub
    },
    {
      id: 'journal',
      title: 'Journal',
      icon: BookOpen,
      description: 'Document your healing journey',
      gradient: 'journal-gradient',
      component: Journal
    },
    {
      id: 'healing-streaks',
      title: 'Healing Streaks',
      icon: Flame,
      description: 'Track your progress and celebrate wins',
      gradient: 'streak-gradient',
      component: HealingStreaks
    },
    {
      id: 'confession-rooms',
      title: 'Anonymous Confessions',
      icon: MessageCircle,
      description: 'Share safely in anonymous spaces',
      gradient: 'confession-gradient',
      component: ConfessionRooms
    }
  ];

  const renderActiveSection = () => {
    const section = sections.find(s => s.id === activeSection);
    if (section) {
      const Component = section.component;
      return <Component onBack={() => setActiveSection('home')} />;
    }
    return null;
  };

  if (activeSection !== 'home') {
    return (
      <div className="min-h-screen"> {/* Removed star-pattern from here as body has the main bg */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            {renderActiveSection()}
          </motion.div>
        </AnimatePresence>
        <Toaster />
      </div>
    );
  }

  return (
    <div className="min-h-screen"> {/* Removed star-pattern from here as body has the main bg */}
      {/* Hero Section */}
      <motion.section 
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: isLoaded ? 1 : 0 }}
        transition={{ duration: 1 }}
      >
        {/* Background Elements - can be adjusted or removed if image bg is preferred without overlays */}
        <div className="absolute inset-0 overflow-hidden z-0"> {/* Ensure this is behind content */}
          <motion.div 
            className="absolute top-20 left-20 w-32 h-32 rounded-full bg-purple-500/5 floating-animation" /* Reduced opacity */
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          />
          <motion.div 
            className="absolute bottom-20 right-20 w-24 h-24 rounded-full bg-pink-500/5 floating-animation" /* Reduced opacity */
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            style={{ animationDelay: '2s' }}
          />
          <motion.div 
            className="absolute top-1/2 left-10 w-16 h-16 rounded-full bg-yellow-500/5 floating-animation" /* Reduced opacity */
            animate={{ rotate: 360 }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            style={{ animationDelay: '4s' }}
          />
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-8"
          >
            <div className="flex items-center justify-center mb-6">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <Star className="w-16 h-16 text-yellow-400 mr-4" />
              </motion.div>
              <h1 className="text-6xl md:text-8xl font-bold gradient-text font-['Playfair_Display'] text-shadow">
                Scars & Stars
              </h1>
              <motion.div
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              >
                <Sparkles className="w-16 h-16 text-purple-400 ml-4" />
              </motion.div>
            </div>
            
            <motion.p 
              className="text-xl md:text-2xl text-gray-100 max-w-3xl mx-auto leading-relaxed" /* Lightened text for contrast */
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              Transform your scars into stars. A safe haven where healing happens, 
              stories are shared, and resilience is born from vulnerability.
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            <div className="flex items-center glass-effect px-6 py-3 rounded-full">
              <Shield className="w-5 h-5 text-green-400 mr-2" />
              <span className="text-sm font-medium text-gray-100">Safe Space</span>
            </div>
            <div className="flex items-center glass-effect px-6 py-3 rounded-full">
              <Users className="w-5 h-5 text-blue-400 mr-2" />
              <span className="text-sm font-medium text-gray-100">Community Support</span>
            </div>
            <div className="flex items-center glass-effect px-6 py-3 rounded-full">
              <Lightbulb className="w-5 h-5 text-yellow-400 mr-2" />
              <span className="text-sm font-medium text-gray-100">Growth Focused</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 1 }}
          >
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg font-semibold rounded-full glow-effect transition-all duration-300 hover:scale-105"
              onClick={() => {
                document.getElementById('features').scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Begin Your Journey
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6 font-['Playfair_Display'] text-shadow">
              Your Healing Toolkit
            </h2>
            <p className="text-xl text-gray-100 max-w-2xl mx-auto"> {/* Lightened text */}
              Four powerful spaces designed to support your journey from pain to purpose
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {sections.map((section, index) => {
              const Icon = section.icon;
              return (
                <motion.div
                  key={section.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05, y: -10 }}
                  className="group cursor-pointer"
                  onClick={() => setActiveSection(section.id)}
                >
                  <div className={`glass-effect rounded-2xl p-8 h-full transition-all duration-300 group-hover:glow-effect ${section.gradient}`}>
                    <div className="flex flex-col items-center text-center">
                      <motion.div
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                        className="mb-6 p-4 rounded-full bg-white/10 group-hover:bg-white/20 transition-all duration-300"
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </motion.div>
                      
                      <h3 className="text-xl font-semibold text-white mb-3 group-hover:gradient-text transition-all duration-300">
                        {section.title}
                      </h3>
                      
                      <p className="text-gray-200 text-sm leading-relaxed mb-6"> {/* Lightened text */}
                        {section.description}
                      </p>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="border-white/20 text-white hover:bg-white/10 hover:border-white/40 transition-all duration-300 group-hover:scale-105"
                      >
                        Explore
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center max-w-4xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-8 font-['Playfair_Display'] text-shadow">
              Our Mission
            </h2>
            
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="text-left">
                <h3 className="text-2xl font-semibold text-white mb-4">
                  Building a Welcoming Space
                </h3>
                <p className="text-gray-100 leading-relaxed mb-6"> {/* Lightened text */}
                  We create a judgment-free environment where every story matters, 
                  every struggle is valid, and every step forward is celebrated.
                </p>
                
                <h3 className="text-2xl font-semibold text-white mb-4">
                  Transforming Pain into Purpose
                </h3>
                <p className="text-gray-100 leading-relaxed"> {/* Lightened text */}
                  Your failures and hardships aren't the end of your story—they're 
                  the raw materials for building something beautiful and resilient.
                </p>
              </div>
              
              <div className="relative">
                <motion.div
                  animate={{ rotate: [0, 2, -2, 0] }} /* Reduced rotation */
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} /* Slower animation */
                  className="glass-effect rounded-2xl p-8 healing-gradient"
                >
                  {/* Image is removed from here as it's now the body background */}
                  <div className="w-full h-64 flex items-center justify-center rounded-lg mb-4 bg-black/20">
                     <Star className="w-24 h-24 text-yellow-400 opacity-50" />
                  </div>
                  
                  <blockquote className="text-center text-white italic">
                    "Every scar tells a story of survival. Every star represents hope reborn."
                  </blockquote>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Toaster />
    </div>
  );
}

export default App;