
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Flame, Plus, Target, Calendar, Trophy, Star, CheckCircle, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const HealingStreaks = ({ onBack }) => {
  const [streaks, setStreaks] = useState([]);
  const [showNewStreakForm, setShowNewStreakForm] = useState(false);
  const [newStreak, setNewStreak] = useState({ title: '', description: '', goal: 7, category: 'wellness' });

  useEffect(() => {
    const savedStreaks = localStorage.getItem('healingStreaks');
    if (savedStreaks) {
      setStreaks(JSON.parse(savedStreaks));
    } else {
      // Sample streaks
      const sampleStreaks = [
        {
          id: 1,
          title: "Daily Meditation",
          description: "10 minutes of mindfulness each day",
          goal: 30,
          category: "wellness",
          currentStreak: 7,
          longestStreak: 12,
          completedDays: ['2024-06-01', '2024-06-02', '2024-06-03', '2024-06-04', '2024-06-05', '2024-06-06', '2024-06-07'],
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          title: "Gratitude Journal",
          description: "Write 3 things I'm grateful for",
          goal: 21,
          category: "mindfulness",
          currentStreak: 4,
          longestStreak: 8,
          completedDays: ['2024-06-04', '2024-06-05', '2024-06-06', '2024-06-07'],
          createdAt: new Date().toISOString()
        }
      ];
      setStreaks(sampleStreaks);
      localStorage.setItem('healingStreaks', JSON.stringify(sampleStreaks));
    }
  }, []);

  const saveStreaks = (updatedStreaks) => {
    setStreaks(updatedStreaks);
    localStorage.setItem('healingStreaks', JSON.stringify(updatedStreaks));
  };

  const handleSubmitStreak = (e) => {
    e.preventDefault();
    if (!newStreak.title.trim() || !newStreak.description.trim()) {
      toast({
        title: "Please fill in all fields",
        description: "Both title and description are required to create a streak.",
        variant: "destructive"
      });
      return;
    }

    const streak = {
      id: Date.now(),
      ...newStreak,
      goal: parseInt(newStreak.goal),
      currentStreak: 0,
      longestStreak: 0,
      completedDays: [],
      createdAt: new Date().toISOString()
    };

    const updatedStreaks = [streak, ...streaks];
    saveStreaks(updatedStreaks);
    setNewStreak({ title: '', description: '', goal: 7, category: 'wellness' });
    setShowNewStreakForm(false);
    
    toast({
      title: "Streak created! 🔥",
      description: "Your new healing streak is ready to track."
    });
  };

  const markDayComplete = (streakId) => {
    const today = new Date().toISOString().split('T')[0];
    const updatedStreaks = streaks.map(streak => {
      if (streak.id === streakId) {
        if (streak.completedDays.includes(today)) {
          toast({
            title: "Already completed today! ✅",
            description: "You've already marked this streak for today."
          });
          return streak;
        }

        const newCompletedDays = [...streak.completedDays, today].sort();
        const newCurrentStreak = calculateCurrentStreak(newCompletedDays);
        const newLongestStreak = Math.max(streak.longestStreak, newCurrentStreak);

        toast({
          title: `Day ${newCurrentStreak} complete! 🎉`,
          description: `Keep up the amazing work on your ${streak.title} streak!`
        });

        return {
          ...streak,
          completedDays: newCompletedDays,
          currentStreak: newCurrentStreak,
          longestStreak: newLongestStreak
        };
      }
      return streak;
    });

    saveStreaks(updatedStreaks);
  };

  const calculateCurrentStreak = (completedDays) => {
    if (completedDays.length === 0) return 0;
    
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    // Check if today or yesterday is completed
    if (!completedDays.includes(today) && !completedDays.includes(yesterday)) {
      return 0;
    }

    let streak = 0;
    let currentDate = new Date();
    
    while (true) {
      const dateStr = currentDate.toISOString().split('T')[0];
      if (completedDays.includes(dateStr)) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else {
        break;
      }
    }
    
    return streak;
  };

  const categories = [
    { id: 'wellness', name: 'Wellness', color: 'from-green-500 to-emerald-500', icon: '🌱' },
    { id: 'mindfulness', name: 'Mindfulness', color: 'from-purple-500 to-indigo-500', icon: '🧘' },
    { id: 'fitness', name: 'Fitness', color: 'from-red-500 to-pink-500', icon: '💪' },
    { id: 'creativity', name: 'Creativity', color: 'from-yellow-500 to-orange-500', icon: '🎨' },
    { id: 'learning', name: 'Learning', color: 'from-blue-500 to-cyan-500', icon: '📚' },
    { id: 'social', name: 'Social', color: 'from-pink-500 to-rose-500', icon: '👥' }
  ];

  const getTodayStatus = (streak) => {
    const today = new Date().toISOString().split('T')[0];
    return streak.completedDays.includes(today);
  };

  const getStreakProgress = (streak) => {
    return Math.min((streak.currentStreak / streak.goal) * 100, 100);
  };

  return (
    <div className="min-h-screen star-pattern">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="mr-4 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold gradient-text font-['Playfair_Display']">
                Healing Streaks
              </h1>
              <p className="text-gray-300 mt-2">Track your progress and celebrate wins</p>
            </div>
          </div>
          
          <Button
            onClick={() => setShowNewStreakForm(true)}
            className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 glow-effect"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Streak
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <div className="glass-effect rounded-xl p-6 text-center streak-gradient">
            <Flame className="w-8 h-8 text-orange-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{streaks.length}</div>
            <div className="text-gray-300 text-sm">Active Streaks</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center streak-gradient">
            <Target className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {streaks.reduce((sum, streak) => sum + streak.currentStreak, 0)}
            </div>
            <div className="text-gray-300 text-sm">Total Days</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center streak-gradient">
            <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {Math.max(...streaks.map(s => s.longestStreak), 0)}
            </div>
            <div className="text-gray-300 text-sm">Longest Streak</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center streak-gradient">
            <Star className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {streaks.filter(s => s.currentStreak >= s.goal).length}
            </div>
            <div className="text-gray-300 text-sm">Goals Reached</div>
          </div>
        </motion.div>

        {/* New Streak Form */}
        <AnimatePresence>
          {showNewStreakForm && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-effect rounded-xl p-6 mb-8"
            >
              <h3 className="text-xl font-semibold text-white mb-4">Create New Streak</h3>
              <form onSubmit={handleSubmitStreak} className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Streak title (e.g., Daily Exercise)"
                    value={newStreak.title}
                    onChange={(e) => setNewStreak({ ...newStreak, title: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Description (e.g., 30 minutes of physical activity)"
                    value={newStreak.description}
                    onChange={(e) => setNewStreak({ ...newStreak, description: e.target.value })}
                    rows={3}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Goal (days)</label>
                    <input
                      type="number"
                      min="1"
                      max="365"
                      value={newStreak.goal}
                      onChange={(e) => setNewStreak({ ...newStreak, goal: e.target.value })}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
                    <select
                      value={newStreak.category}
                      onChange={(e) => setNewStreak({ ...newStreak, category: e.target.value })}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                    >
                      {categories.map(category => (
                        <option key={category.id} value={category.id} className="bg-gray-800">
                          {category.icon} {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button type="submit" className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700">
                    Create Streak
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowNewStreakForm(false)}
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Streaks */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {streaks.map((streak, index) => {
            const category = categories.find(c => c.id === streak.category);
            const progress = getStreakProgress(streak);
            const isCompletedToday = getTodayStatus(streak);
            
            return (
              <motion.div
                key={streak.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 hover:glow-effect transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${category.color} text-white flex items-center gap-1`}>
                        <span>{category.icon}</span>
                        <span>{category.name}</span>
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-1">{streak.title}</h3>
                    <p className="text-gray-300 text-sm mb-3">{streak.description}</p>
                  </div>
                </div>

                {/* Progress */}
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-300">Progress</span>
                    <span className="text-sm text-white font-medium">
                      {streak.currentStreak}/{streak.goal} days
                    </span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <motion.div
                      className={`h-2 rounded-full bg-gradient-to-r ${category.color}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-xl font-bold text-white">{streak.currentStreak}</div>
                    <div className="text-xs text-gray-300">Current</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-white">{streak.longestStreak}</div>
                    <div className="text-xs text-gray-300">Best</div>
                  </div>
                </div>

                {/* Action Button */}
                <Button
                  onClick={() => markDayComplete(streak.id)}
                  disabled={isCompletedToday}
                  className={`w-full ${
                    isCompletedToday 
                      ? 'bg-green-600 hover:bg-green-600 cursor-not-allowed' 
                      : `bg-gradient-to-r ${category.color} hover:opacity-90`
                  } transition-all duration-300`}
                >
                  {isCompletedToday ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Completed Today!
                    </>
                  ) : (
                    <>
                      <Circle className="w-4 h-4 mr-2" />
                      Mark Complete
                    </>
                  )}
                </Button>

                {/* Achievement Badge */}
                {streak.currentStreak >= streak.goal && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-2"
                  >
                    <Trophy className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {streaks.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Flame className="w-16 h-16 text-orange-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Start your first streak</h3>
            <p className="text-gray-300 mb-6">Create a healing habit and track your progress!</p>
            <Button
              onClick={() => setShowNewStreakForm(true)}
              className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
            >
              Create Your First Streak
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default HealingStreaks;
