
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Heart, MessageCircle, Users, Plus, Star, ThumbsUp, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const HealingHub = ({ onBack }) => {
  const [stories, setStories] = useState([]);
  const [showNewStoryForm, setShowNewStoryForm] = useState(false);
  const [newStory, setNewStory] = useState({ title: '', content: '', category: 'healing' });

  useEffect(() => {
    const savedStories = localStorage.getItem('healingStories');
    if (savedStories) {
      setStories(JSON.parse(savedStories));
    } else {
      // Sample stories
      const sampleStories = [
        {
          id: 1,
          title: "Finding Light After Loss",
          content: "Six months ago, I lost my job and felt like my world was crumbling. Today, I started my own business and couldn't be happier. Sometimes the universe pushes us toward our true calling.",
          author: "Anonymous",
          category: "healing",
          likes: 24,
          comments: 8,
          timestamp: new Date().toISOString()
        },
        {
          id: 2,
          title: "Overcoming Social Anxiety",
          content: "I used to be terrified of speaking in public. Last week, I gave my first presentation at work and received a standing ovation. Small steps lead to big victories.",
          author: "Anonymous",
          category: "growth",
          likes: 18,
          comments: 12,
          timestamp: new Date().toISOString()
        }
      ];
      setStories(sampleStories);
      localStorage.setItem('healingStories', JSON.stringify(sampleStories));
    }
  }, []);

  const saveStories = (updatedStories) => {
    setStories(updatedStories);
    localStorage.setItem('healingStories', JSON.stringify(updatedStories));
  };

  const handleSubmitStory = (e) => {
    e.preventDefault();
    if (!newStory.title.trim() || !newStory.content.trim()) {
      toast({
        title: "Please fill in all fields",
        description: "Both title and content are required to share your story.",
        variant: "destructive"
      });
      return;
    }

    const story = {
      id: Date.now(),
      ...newStory,
      author: "Anonymous",
      likes: 0,
      comments: 0,
      timestamp: new Date().toISOString()
    };

    const updatedStories = [story, ...stories];
    saveStories(updatedStories);
    setNewStory({ title: '', content: '', category: 'healing' });
    setShowNewStoryForm(false);
    
    toast({
      title: "Story shared successfully! ✨",
      description: "Your story has been added to the healing hub."
    });
  };

  const handleLike = (storyId) => {
    const updatedStories = stories.map(story => 
      story.id === storyId 
        ? { ...story, likes: story.likes + 1 }
        : story
    );
    saveStories(updatedStories);
    
    toast({
      title: "Thank you for spreading love! ❤️",
      description: "Your support means everything to our community."
    });
  };

  const categories = [
    { id: 'healing', name: 'Healing', color: 'from-purple-500 to-pink-500' },
    { id: 'growth', name: 'Growth', color: 'from-blue-500 to-cyan-500' },
    { id: 'resilience', name: 'Resilience', color: 'from-green-500 to-emerald-500' },
    { id: 'hope', name: 'Hope', color: 'from-yellow-500 to-orange-500' }
  ];

  return (
    <div className="min-h-screen star-pattern">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="mr-4 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold gradient-text font-['Playfair_Display']">
                Healing Hub
              </h1>
              <p className="text-gray-300 mt-2">Share your journey, inspire others</p>
            </div>
          </div>
          
          <Button
            onClick={() => setShowNewStoryForm(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 glow-effect"
          >
            <Plus className="w-4 h-4 mr-2" />
            Share Story
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <div className="glass-effect rounded-xl p-6 text-center">
            <Heart className="w-8 h-8 text-red-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{stories.reduce((sum, story) => sum + story.likes, 0)}</div>
            <div className="text-gray-300 text-sm">Hearts Given</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{stories.length}</div>
            <div className="text-gray-300 text-sm">Stories Shared</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center">
            <MessageCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{stories.reduce((sum, story) => sum + story.comments, 0)}</div>
            <div className="text-gray-300 text-sm">Comments</div>
          </div>
        </motion.div>

        {/* New Story Form */}
        <AnimatePresence>
          {showNewStoryForm && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-effect rounded-xl p-6 mb-8"
            >
              <h3 className="text-xl font-semibold text-white mb-4">Share Your Story</h3>
              <form onSubmit={handleSubmitStory} className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Story title..."
                    value={newStory.title}
                    onChange={(e) => setNewStory({ ...newStory, title: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Share your journey, struggles, victories, or lessons learned..."
                    value={newStory.content}
                    onChange={(e) => setNewStory({ ...newStory, content: e.target.value })}
                    rows={4}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  />
                </div>
                <div>
                  <select
                    value={newStory.category}
                    onChange={(e) => setNewStory({ ...newStory, category: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    {categories.map(category => (
                      <option key={category.id} value={category.id} className="bg-gray-800">
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-3">
                  <Button type="submit" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Share Story
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowNewStoryForm(false)}
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stories */}
        <div className="space-y-6">
          {stories.map((story, index) => {
            const category = categories.find(c => c.id === story.category);
            return (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 hover:glow-effect transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${category.color} text-white`}>
                        {category.name}
                      </span>
                      <span className="text-gray-400 text-sm">
                        {new Date(story.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{story.title}</h3>
                    <p className="text-gray-300 leading-relaxed">{story.content}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => handleLike(story.id)}
                      className="flex items-center gap-2 text-gray-400 hover:text-red-400 transition-colors"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span>{story.likes}</span>
                    </button>
                    <div className="flex items-center gap-2 text-gray-400">
                      <MessageCircle className="w-4 h-4" />
                      <span>{story.comments}</span>
                    </div>
                  </div>
                  
                  <button className="flex items-center gap-2 text-gray-400 hover:text-blue-400 transition-colors">
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {stories.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Star className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No stories yet</h3>
            <p className="text-gray-300 mb-6">Be the first to share your healing journey!</p>
            <Button
              onClick={() => setShowNewStoryForm(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              Share Your Story
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default HealingHub;
