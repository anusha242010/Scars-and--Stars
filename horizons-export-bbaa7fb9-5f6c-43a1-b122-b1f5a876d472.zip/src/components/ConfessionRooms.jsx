
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, MessageCircle, Plus, Lock, Users, Heart, Send, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ConfessionRooms = ({ onBack }) => {
  const [rooms, setRooms] = useState([]);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [confessions, setConfessions] = useState([]);
  const [showNewRoomForm, setShowNewRoomForm] = useState(false);
  const [showNewConfessionForm, setShowNewConfessionForm] = useState(false);
  const [newRoom, setNewRoom] = useState({ name: '', description: '', category: 'general' });
  const [newConfession, setNewConfession] = useState({ content: '', isAnonymous: true });

  useEffect(() => {
    const savedRooms = localStorage.getItem('confessionRooms');
    const savedConfessions = localStorage.getItem('confessions');
    
    if (savedRooms) {
      setRooms(JSON.parse(savedRooms));
    } else {
      // Sample rooms
      const sampleRooms = [
        {
          id: 1,
          name: "Safe Haven",
          description: "A gentle space for sharing your deepest thoughts",
          category: "general",
          memberCount: 127,
          confessionCount: 45,
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          name: "Healing Hearts",
          description: "Share your journey through heartbreak and healing",
          category: "relationships",
          memberCount: 89,
          confessionCount: 32,
          createdAt: new Date().toISOString()
        },
        {
          id: 3,
          name: "Anxiety Anonymous",
          description: "A supportive space for those dealing with anxiety",
          category: "mental-health",
          memberCount: 156,
          confessionCount: 78,
          createdAt: new Date().toISOString()
        }
      ];
      setRooms(sampleRooms);
      localStorage.setItem('confessionRooms', JSON.stringify(sampleRooms));
    }

    if (savedConfessions) {
      setConfessions(JSON.parse(savedConfessions));
    } else {
      // Sample confessions
      const sampleConfessions = [
        {
          id: 1,
          roomId: 1,
          content: "I've been struggling with self-doubt for years, but today I finally applied for my dream job. Sometimes the scariest step is the first one.",
          isAnonymous: true,
          author: "Anonymous",
          likes: 12,
          replies: 3,
          timestamp: new Date().toISOString()
        },
        {
          id: 2,
          roomId: 2,
          content: "After my divorce, I thought I'd never trust again. But I'm learning that healing doesn't mean forgetting - it means growing stronger.",
          isAnonymous: true,
          author: "Anonymous",
          likes: 8,
          replies: 5,
          timestamp: new Date().toISOString()
        }
      ];
      setConfessions(sampleConfessions);
      localStorage.setItem('confessions', JSON.stringify(sampleConfessions));
    }
  }, []);

  const saveRooms = (updatedRooms) => {
    setRooms(updatedRooms);
    localStorage.setItem('confessionRooms', JSON.stringify(updatedRooms));
  };

  const saveConfessions = (updatedConfessions) => {
    setConfessions(updatedConfessions);
    localStorage.setItem('confessions', JSON.stringify(updatedConfessions));
  };

  const handleCreateRoom = (e) => {
    e.preventDefault();
    if (!newRoom.name.trim() || !newRoom.description.trim()) {
      toast({
        title: "Please fill in all fields",
        description: "Both name and description are required to create a room.",
        variant: "destructive"
      });
      return;
    }

    const room = {
      id: Date.now(),
      ...newRoom,
      memberCount: 1,
      confessionCount: 0,
      createdAt: new Date().toISOString()
    };

    const updatedRooms = [room, ...rooms];
    saveRooms(updatedRooms);
    setNewRoom({ name: '', description: '', category: 'general' });
    setShowNewRoomForm(false);
    
    toast({
      title: "Room created! 🏠",
      description: "Your safe space is ready for confessions."
    });
  };

  const handleSubmitConfession = (e) => {
    e.preventDefault();
    if (!newConfession.content.trim()) {
      toast({
        title: "Please write your confession",
        description: "Your thoughts matter - share what's on your mind.",
        variant: "destructive"
      });
      return;
    }

    const confession = {
      id: Date.now(),
      roomId: selectedRoom.id,
      content: newConfession.content,
      isAnonymous: newConfession.isAnonymous,
      author: newConfession.isAnonymous ? "Anonymous" : "You",
      likes: 0,
      replies: 0,
      timestamp: new Date().toISOString()
    };

    const updatedConfessions = [confession, ...confessions];
    saveConfessions(updatedConfessions);

    // Update room confession count
    const updatedRooms = rooms.map(room => 
      room.id === selectedRoom.id 
        ? { ...room, confessionCount: room.confessionCount + 1 }
        : room
    );
    saveRooms(updatedRooms);
    setSelectedRoom({ ...selectedRoom, confessionCount: selectedRoom.confessionCount + 1 });

    setNewConfession({ content: '', isAnonymous: true });
    setShowNewConfessionForm(false);
    
    toast({
      title: "Confession shared! 💜",
      description: "Thank you for trusting this space with your thoughts."
    });
  };

  const handleLikeConfession = (confessionId) => {
    const updatedConfessions = confessions.map(confession => 
      confession.id === confessionId 
        ? { ...confession, likes: confession.likes + 1 }
        : confession
    );
    saveConfessions(updatedConfessions);
    
    toast({
      title: "Support sent! ❤️",
      description: "Your compassion makes a difference."
    });
  };

  const categories = [
    { id: 'general', name: 'General', color: 'from-purple-500 to-pink-500', icon: '💭' },
    { id: 'relationships', name: 'Relationships', color: 'from-red-500 to-pink-500', icon: '💕' },
    { id: 'mental-health', name: 'Mental Health', color: 'from-blue-500 to-cyan-500', icon: '🧠' },
    { id: 'family', name: 'Family', color: 'from-green-500 to-emerald-500', icon: '👨‍👩‍👧‍👦' },
    { id: 'work', name: 'Work & Career', color: 'from-yellow-500 to-orange-500', icon: '💼' },
    { id: 'addiction', name: 'Addiction Recovery', color: 'from-indigo-500 to-purple-500', icon: '🌱' }
  ];

  const getRoomConfessions = (roomId) => {
    return confessions.filter(confession => confession.roomId === roomId);
  };

  if (selectedRoom) {
    const roomConfessions = getRoomConfessions(selectedRoom.id);
    const category = categories.find(c => c.id === selectedRoom.category);

    return (
      <div className="min-h-screen star-pattern">
        <div className="container mx-auto px-6 py-8">
          {/* Room Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between mb-8"
          >
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedRoom(null)}
                className="mr-4 text-white hover:bg-white/10"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Rooms
              </Button>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-bold gradient-text font-['Playfair_Display']">
                    {selectedRoom.name}
                  </h1>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${category.color} text-white flex items-center gap-1`}>
                    <span>{category.icon}</span>
                    <span>{category.name}</span>
                  </span>
                </div>
                <p className="text-gray-300">{selectedRoom.description}</p>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {selectedRoom.memberCount} members
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    {selectedRoom.confessionCount} confessions
                  </span>
                </div>
              </div>
            </div>
            
            <Button
              onClick={() => setShowNewConfessionForm(true)}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 glow-effect"
            >
              <Plus className="w-4 h-4 mr-2" />
              Share Confession
            </Button>
          </motion.div>

          {/* New Confession Form */}
          <AnimatePresence>
            {showNewConfessionForm && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="glass-effect rounded-xl p-6 mb-8 confession-gradient"
              >
                <h3 className="text-xl font-semibold text-white mb-4">Share Your Confession</h3>
                <form onSubmit={handleSubmitConfession} className="space-y-4">
                  <div>
                    <textarea
                      placeholder="Share what's on your heart... This is a safe space."
                      value={newConfession.content}
                      onChange={(e) => setNewConfession({ ...newConfession, content: e.target.value })}
                      rows={6}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500 resize-none"
                    />
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setNewConfession({ ...newConfession, isAnonymous: !newConfession.isAnonymous })}
                      className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
                    >
                      {newConfession.isAnonymous ? (
                        <>
                          <EyeOff className="w-4 h-4" />
                          <span>Anonymous</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-4 h-4" />
                          <span>Show my name</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="flex gap-3">
                    <Button type="submit" className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700">
                      <Send className="w-4 h-4 mr-2" />
                      Share Confession
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowNewConfessionForm(false)}
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Confessions */}
          <div className="space-y-6">
            {roomConfessions.map((confession, index) => (
              <motion.div
                key={confession.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 hover:glow-effect transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-gray-400 text-sm flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        {confession.author}
                      </span>
                      <span className="text-gray-400 text-sm">
                        {new Date(confession.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-300 leading-relaxed text-lg">{confession.content}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <button
                    onClick={() => handleLikeConfession(confession.id)}
                    className="flex items-center gap-2 text-gray-400 hover:text-red-400 transition-colors"
                  >
                    <Heart className="w-4 h-4" />
                    <span>{confession.likes} hearts</span>
                  </button>
                  
                  <div className="flex items-center gap-2 text-gray-400">
                    <MessageCircle className="w-4 h-4" />
                    <span>{confession.replies} replies</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {roomConfessions.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <MessageCircle className="w-16 h-16 text-pink-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No confessions yet</h3>
              <p className="text-gray-300 mb-6">Be the first to share in this safe space!</p>
              <Button
                onClick={() => setShowNewConfessionForm(true)}
                className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
              >
                Share Your Confession
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen star-pattern">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="mr-4 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold gradient-text font-['Playfair_Display']">
                Anonymous Confessions
              </h1>
              <p className="text-gray-300 mt-2">Share safely in anonymous spaces</p>
            </div>
          </div>
          
          <Button
            onClick={() => setShowNewRoomForm(true)}
            className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 glow-effect"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Room
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <div className="glass-effect rounded-xl p-6 text-center confession-gradient">
            <MessageCircle className="w-8 h-8 text-pink-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{rooms.length}</div>
            <div className="text-gray-300 text-sm">Safe Rooms</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center confession-gradient">
            <Users className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {rooms.reduce((sum, room) => sum + room.memberCount, 0)}
            </div>
            <div className="text-gray-300 text-sm">Community Members</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center confession-gradient">
            <Heart className="w-8 h-8 text-red-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {confessions.reduce((sum, confession) => sum + confession.likes, 0)}
            </div>
            <div className="text-gray-300 text-sm">Hearts Given</div>
          </div>
        </motion.div>

        {/* New Room Form */}
        <AnimatePresence>
          {showNewRoomForm && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-effect rounded-xl p-6 mb-8"
            >
              <h3 className="text-xl font-semibold text-white mb-4">Create Safe Room</h3>
              <form onSubmit={handleCreateRoom} className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Room name (e.g., Healing Hearts)"
                    value={newRoom.name}
                    onChange={(e) => setNewRoom({ ...newRoom, name: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Room description and guidelines..."
                    value={newRoom.description}
                    onChange={(e) => setNewRoom({ ...newRoom, description: e.target.value })}
                    rows={3}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500 resize-none"
                  />
                </div>
                <div>
                  <select
                    value={newRoom.category}
                    onChange={(e) => setNewRoom({ ...newRoom, category: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-pink-500"
                  >
                    {categories.map(category => (
                      <option key={category.id} value={category.id} className="bg-gray-800">
                        {category.icon} {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-3">
                  <Button type="submit" className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700">
                    Create Room
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowNewRoomForm(false)}
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Rooms */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room, index) => {
            const category = categories.find(c => c.id === room.category);
            return (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="glass-effect rounded-xl p-6 cursor-pointer hover:glow-effect transition-all duration-300 confession-gradient"
                onClick={() => setSelectedRoom(room)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${category.color} text-white flex items-center gap-1`}>
                        <span>{category.icon}</span>
                        <span>{category.name}</span>
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">{room.name}</h3>
                    <p className="text-gray-300 text-sm leading-relaxed">{room.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {room.memberCount}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {room.confessionCount}
                    </span>
                  </div>
                  <Lock className="w-4 h-4 text-gray-400" />
                </div>
              </motion.div>
            );
          })}
        </div>

        {rooms.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <MessageCircle className="w-16 h-16 text-pink-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No rooms yet</h3>
            <p className="text-gray-300 mb-6">Create the first safe space for anonymous sharing!</p>
            <Button
              onClick={() => setShowNewRoomForm(true)}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
            >
              Create First Room
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default ConfessionRooms;
