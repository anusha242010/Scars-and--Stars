
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, BookOpen, Plus, Calendar, Search, Filter, Edit3, Trash2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Journal = ({ onBack }) => {
  const [entries, setEntries] = useState([]);
  const [showNewEntryForm, setShowNewEntryForm] = useState(false);
  const [newEntry, setNewEntry] = useState({ title: '', content: '', mood: 'neutral', tags: '' });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMood, setSelectedMood] = useState('all');
  const [editingEntry, setEditingEntry] = useState(null);

  useEffect(() => {
    const savedEntries = localStorage.getItem('journalEntries');
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries));
    }
  }, []);

  const saveEntries = (updatedEntries) => {
    setEntries(updatedEntries);
    localStorage.setItem('journalEntries', JSON.stringify(updatedEntries));
  };

  const handleSubmitEntry = (e) => {
    e.preventDefault();
    if (!newEntry.title.trim() || !newEntry.content.trim()) {
      toast({
        title: "Please fill in all fields",
        description: "Both title and content are required for your journal entry.",
        variant: "destructive"
      });
      return;
    }

    const entry = {
      id: editingEntry ? editingEntry.id : Date.now(),
      ...newEntry,
      tags: newEntry.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      timestamp: editingEntry ? editingEntry.timestamp : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    let updatedEntries;
    if (editingEntry) {
      updatedEntries = entries.map(e => e.id === editingEntry.id ? entry : e);
      toast({
        title: "Entry updated! ✨",
        description: "Your journal entry has been successfully updated."
      });
    } else {
      updatedEntries = [entry, ...entries];
      toast({
        title: "Entry saved! 📝",
        description: "Your thoughts have been safely stored in your journal."
      });
    }

    saveEntries(updatedEntries);
    setNewEntry({ title: '', content: '', mood: 'neutral', tags: '' });
    setShowNewEntryForm(false);
    setEditingEntry(null);
  };

  const handleEditEntry = (entry) => {
    setNewEntry({
      title: entry.title,
      content: entry.content,
      mood: entry.mood,
      tags: entry.tags.join(', ')
    });
    setEditingEntry(entry);
    setShowNewEntryForm(true);
  };

  const handleDeleteEntry = (entryId) => {
    const updatedEntries = entries.filter(entry => entry.id !== entryId);
    saveEntries(updatedEntries);
    toast({
      title: "Entry deleted",
      description: "Your journal entry has been removed."
    });
  };

  const moods = [
    { id: 'happy', name: 'Happy', emoji: '😊', color: 'from-yellow-400 to-orange-400' },
    { id: 'grateful', name: 'Grateful', emoji: '🙏', color: 'from-green-400 to-emerald-400' },
    { id: 'peaceful', name: 'Peaceful', emoji: '😌', color: 'from-blue-400 to-cyan-400' },
    { id: 'neutral', name: 'Neutral', emoji: '😐', color: 'from-gray-400 to-gray-500' },
    { id: 'sad', name: 'Sad', emoji: '😢', color: 'from-blue-500 to-indigo-500' },
    { id: 'anxious', name: 'Anxious', emoji: '😰', color: 'from-purple-500 to-pink-500' },
    { id: 'angry', name: 'Angry', emoji: '😠', color: 'from-red-500 to-orange-500' },
    { id: 'hopeful', name: 'Hopeful', emoji: '🌟', color: 'from-purple-400 to-pink-400' }
  ];

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesMood = selectedMood === 'all' || entry.mood === selectedMood;
    return matchesSearch && matchesMood;
  });

  return (
    <div className="min-h-screen star-pattern">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="mr-4 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold gradient-text font-['Playfair_Display']">
                Personal Journal
              </h1>
              <p className="text-gray-300 mt-2">Document your healing journey</p>
            </div>
          </div>
          
          <Button
            onClick={() => {
              setShowNewEntryForm(true);
              setEditingEntry(null);
              setNewEntry({ title: '', content: '', mood: 'neutral', tags: '' });
            }}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 glow-effect"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Entry
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <div className="glass-effect rounded-xl p-6 text-center journal-gradient">
            <BookOpen className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{entries.length}</div>
            <div className="text-gray-300 text-sm">Total Entries</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center journal-gradient">
            <Calendar className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {entries.length > 0 ? Math.ceil((Date.now() - new Date(entries[entries.length - 1].timestamp).getTime()) / (1000 * 60 * 60 * 24)) : 0}
            </div>
            <div className="text-gray-300 text-sm">Days Journaling</div>
          </div>
          <div className="glass-effect rounded-xl p-6 text-center journal-gradient">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {entries.reduce((sum, entry) => sum + entry.content.split(' ').length, 0)}
            </div>
            <div className="text-gray-300 text-sm">Words Written</div>
          </div>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-effect rounded-xl p-6 mb-8"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search entries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <select
                value={selectedMood}
                onChange={(e) => setSelectedMood(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-lg pl-10 pr-8 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all" className="bg-gray-800">All Moods</option>
                {moods.map(mood => (
                  <option key={mood.id} value={mood.id} className="bg-gray-800">
                    {mood.emoji} {mood.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </motion.div>

        {/* New Entry Form */}
        <AnimatePresence>
          {showNewEntryForm && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-effect rounded-xl p-6 mb-8"
            >
              <h3 className="text-xl font-semibold text-white mb-4">
                {editingEntry ? 'Edit Entry' : 'New Journal Entry'}
              </h3>
              <form onSubmit={handleSubmitEntry} className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Entry title..."
                    value={newEntry.title}
                    onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <textarea
                    placeholder="What's on your mind today? Share your thoughts, feelings, experiences..."
                    value={newEntry.content}
                    onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                    rows={6}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Mood</label>
                    <select
                      value={newEntry.mood}
                      onChange={(e) => setNewEntry({ ...newEntry, mood: e.target.value })}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {moods.map(mood => (
                        <option key={mood.id} value={mood.id} className="bg-gray-800">
                          {mood.emoji} {mood.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Tags (comma separated)</label>
                    <input
                      type="text"
                      placeholder="healing, growth, reflection..."
                      value={newEntry.tags}
                      onChange={(e) => setNewEntry({ ...newEntry, tags: e.target.value })}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    {editingEntry ? 'Update Entry' : 'Save Entry'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setShowNewEntryForm(false);
                      setEditingEntry(null);
                      setNewEntry({ title: '', content: '', mood: 'neutral', tags: '' });
                    }}
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Entries */}
        <div className="space-y-6">
          {filteredEntries.map((entry, index) => {
            const mood = moods.find(m => m.id === entry.mood);
            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 hover:glow-effect transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${mood.color} text-white flex items-center gap-1`}>
                        <span>{mood.emoji}</span>
                        <span>{mood.name}</span>
                      </span>
                      <span className="text-gray-400 text-sm">
                        {new Date(entry.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{entry.title}</h3>
                    <p className="text-gray-300 leading-relaxed mb-3">{entry.content}</p>
                    {entry.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {entry.tags.map((tag, tagIndex) => (
                          <span key={tagIndex} className="px-2 py-1 bg-white/10 rounded-full text-xs text-gray-300">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => handleEditEntry(entry)}
                      className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteEntry(entry.id)}
                      className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {filteredEntries.length === 0 && entries.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No entries found</h3>
            <p className="text-gray-300">Try adjusting your search or filter criteria.</p>
          </motion.div>
        )}

        {entries.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <BookOpen className="w-16 h-16 text-blue-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Start your journal</h3>
            <p className="text-gray-300 mb-6">Begin documenting your healing journey today!</p>
            <Button
              onClick={() => setShowNewEntryForm(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Write Your First Entry
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Journal;
